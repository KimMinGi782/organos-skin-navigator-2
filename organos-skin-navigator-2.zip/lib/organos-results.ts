// Result parsing. HTTP 200 and task_status "success" are different things;
// "success" with no extractable scores is still reported as a parse failure.
//
// The exact response schema is UNVERIFIED. Official notes only say scores live
// under `results` or `output[]` and each concern has `ui_score` (higher = better)
// and `raw_score`. This parser is tolerant and never invents values.

export type ConcernScore = { concern: string; uiScore: number };

export type ParsedResult =
  | { ok: true; scores: ConcernScore[]; skinType?: string }
  | { ok: false; reason: "task_error" | "not_success" | "no_scores"; code?: string; shape?: unknown };

const SUCCESS = new Set(["success", "succeed", "completed"]);
const FAILED = new Set(["error", "failed"]);

export function classifyStatus(status: unknown): "success" | "error" | "pending" {
  const s = typeof status === "string" ? status.toLowerCase() : "";
  if (SUCCESS.has(s)) return "success";
  if (FAILED.has(s)) return "error";
  return "pending";
}

function clamp(n: number): number {
  return Math.max(0, Math.min(100, n));
}

export function parseResult(data: any): ParsedResult {
  const kind = classifyStatus(data?.task_status ?? data?.status);
  if (kind === "error") {
    return { ok: false, reason: "task_error", code: typeof data?.error === "string" ? data.error : data?.error_code };
  }
  if (kind !== "success") return { ok: false, reason: "not_success" };

  const scores: ConcernScore[] = [];
  const seen = new Set<string>();
  let skinType: string | undefined;

  // Walk the whole payload: scores may sit under results, results.output[], etc.
  const visit = (node: any, key: string, depth: number) => {
    if (depth > 6 || node === null || typeof node !== "object") return;
    if (!Array.isArray(node)) {
      if (typeof node.ui_score === "number" && Number.isFinite(node.ui_score)) {
        const raw = node.type ?? node.name ?? node.concern ?? key;
        const name = typeof raw === "string" && raw ? raw : key;
        if (!seen.has(name)) {
          seen.add(name);
          scores.push({ concern: name, uiScore: clamp(node.ui_score) });
        }
        return;
      }
      if (typeof node.skin_type === "string" && !skinType) skinType = node.skin_type;
    }
    for (const [k, v] of Object.entries(node)) visit(v, k, depth + 1);
  };
  visit(data?.results ?? data?.output ?? data?.result ?? data, "", 0);

  if (scores.length === 0) return { ok: false, reason: "no_scores", shape: describeShape(data) };
  return { ok: true, scores, skinType };
}

/** Structure only (keys, types, array lengths). Never includes string values, so no URLs/tokens leak. */
export function describeShape(v: any, depth = 0): unknown {
  if (v === null) return "null";
  if (Array.isArray(v)) return depth > 5 ? "array" : { array: v.length, first: v.length ? describeShape(v[0], depth + 1) : null };
  if (typeof v === "object") {
    if (depth > 5) return "object";
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v).slice(0, 30)) out[k] = describeShape(v[k], depth + 1);
    return out;
  }
  return typeof v;
}
